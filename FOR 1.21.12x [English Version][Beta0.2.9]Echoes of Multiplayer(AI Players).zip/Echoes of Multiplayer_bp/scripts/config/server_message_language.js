export const serverAnnouncements = [
    "Welcome! Join our Discord for the latest server news and events!",
    "Please follow the server rules and play fair. Cheating is strictly prohibited.",
    "This mod is currently in beta and requires a lot of testing. We welcome you to post feedback, suggestions, and bug reports in the comments section on CurseForge or MCPEDL. Let's make it better together!"
];