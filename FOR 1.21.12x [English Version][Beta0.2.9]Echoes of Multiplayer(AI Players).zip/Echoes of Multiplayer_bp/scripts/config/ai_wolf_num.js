export const DOGS_PER_TIER = {
    "wooden": { min: 0, max: 1 },
    "stone":  { min: 0, max: 1 },
    "copper": { min: 0, max: 2 },
    "iron":   { min: 0, max: 2 },
    "diamond":   { min: 0, max: 3 },
    "diamond_pro":   { min: 0, max: 3 },
};