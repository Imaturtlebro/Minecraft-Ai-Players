export const namePartA_Adjectives = [
    "Crazy", "Bold", "Mysterious", "Pensive", "Happy", "Melancholy", "Running", "Sneaking", "Invincible", "Shy",
    "Sinister", "Kind", "Grumpy", "Calm", "Comical", "Brave", "Lucky", "Unlucky", "Glowing", "Giant",
    "Tiny", "Soaring", "Durable", "Rigid", "Fearsome", "Afraid", "Vain", "Powerful", "Frank", "Honest",
    "Tender", "Laughing", "Dominant", "Ancient", "Forgotten", "Lost", "Sleeping", "Wandering", "Silent", "Whispering",
    "Raging", "Peaceful", "Cunning", "Wise", "Foolish", "Epic", "Legendary", "Fabled", "Hidden", "Secret",
    "Flying", "Swimming", "Diving", "Burning", "Frozen", "Electric", "Thundering", "Shadowy", "Radiant", "Glimmering"
];

export const namePartB_Conjunctions = [
    "The", "Of", "And", "But", "Or", "Who", "Is"
];

export const namePartC_Nouns = [
    "Stone", "Pencil", "Sky", "Ocean", "Flame", "Ice", "Diamond", "Creeper", "Workbench", "Furnace",
    "Pig", "Ingot", "Explorer", "Builder", "Ghost", "Legend", "Soldier", "Keyboard", "Dinosaur", "Cola",
    "Cabinet", "Glass", "Steel", "Warlord", "Gale", "Bread", "Screw", "Bench", "Specter", "Leopard",
    "Flower", "Serpent", "Champion", "Golem", "Panda", "Fox", "Wolf", "Skeleton", "Zombie", "Enderman",
    "Guardian", "Warden", "Pillager", "Witch", "Phantom", "Mountain", "River", "Forest", "Desert", "Cave",
    "Castle", "Void", "Abyss", "Storm", "Oracle", "Seeker", "Wanderer", "Paladin", "Rogue", "Mage"
];

export const presetNames = [
    "指令师_暖风", "虚名的丫环", "青春帝帝", "打愤乌鸦哥", "奥克尔克", "agodjaogiuo", "超猛白白", "漫化态侍者", "一个可怜的L", "凌寒很可爱", "xiaocuiyi2", "SaintJust1794", "海岛奇兵", "蛞糯迪奥哒", "一只普奇神父", "Dream", "Herobrine", "Notch", "Technoblade", "藤白巧", "MC_Undy", "卡利托斯", "阙提", "嘞U去你", "EJalAK", "谱子pp", "车皮卡cs", "名字不想太人机", "𬘫林Z", "b站整活之人哦", "HXJ2023", "好的WHi", "幽灵2720", "穷叉叉yz的新号", "禾别辜负哭发do", "oL63hw", "等不及睡", "幸德秋水", "陈某人jntm", "ExcessCone02651", "birbstrems", "Baiming511", "RubyStew8770", "zhanglunyan88","NeedyBooch29170","MCpingming","NeedyBooch29170","IceCoke191919","ice tea5566","qingfeng556623","milk cow1145","BaiYunLiu mc","zhangxinrui095","leisai2838", "AERC9386", "ca5s1e", "miku5672", "potatoesPVP6168", "Yukiko fish", "Zi_Min", "ExploadingTNT", "95强", "后天", "爽脆萌柚子", "scscwe", "Icedream492", "OtherHades2073", "baikaishui mc", "狂笑的蛇写散文", "MinecraftHXY", "Herobrine超低级分身", "星河星河之海","Ren_Sheng","Pink_Fish","Hacker_and_Killer","DeanWinchester","SamWinchester","homelander","IShowSpeed","MrBeast","retard4692","xqc","Cromwell95","Lenin1917","VisualRex612","尘轩冥王"
];